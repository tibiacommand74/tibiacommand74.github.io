@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Instale o Node.js LTS antes de iniciar.
 pause
 exit /b 1
)
node server.cjs
pause
