# Tibia Command — VS Code — 0.31.0

Programa local para Tibia 7.4. Inclui os recursos da 0.24, banco SQLite, backups automáticos em arquivo e planejador de hunts.

## Atualizar e executar

1. Na versão anterior, exporte um backup em **Servidores e Backup**.
2. Encerre o servidor antigo com **Ctrl+C**.
3. Extraia o ZIP inteiro e abra a pasta `Tibia-Command-VSCode` no VS Code.
4. Use **Node.js 22.13 ou superior** (recomendado: versão LTS atual).
5. No terminal dessa pasta, execute:

```sh
npm start
```

6. Abra **http://127.0.0.1:7474** no navegador.

Não é necessário `npm install`. Alternativamente, execute `INICIAR_WINDOWS.bat` e abra o endereço indicado no terminal.

Ao abrir, se o banco ainda não tiver cadastros, o programa tenta migrar os registros da versão anterior do mesmo endereço e perfil do navegador. Se seus dados não aparecerem, importe o backup exportado. O HTML aberto como arquivo tem armazenamento separado e exige importação.

## Banco local e backups

No Windows, o banco fica normalmente em `%LOCALAPPDATA%\TibiaCommand\tibia-command.sqlite`. A aba **Servidores e Backup** mostra o caminho efetivamente usado.

Os dados agora são lidos do mesmo banco pelos navegadores do computador. A gravação usa transações SQLite. Abas desatualizadas não podem sobrescrever silenciosamente alterações: recarregue a aba quando houver conflito.

Antes de alterar cadastros já gravados, o servidor cria um backup JSON em `backups`, na pasta de dados, mantendo as últimas 30 cópias. É possível baixar ou restaurar essas cópias na aba de backup. Ainda exporte uma cópia para outro disco se quiser proteção contra falha do computador.

As contas e senhas do cofre permanecem criptografadas. Nomes de contas e personagens são metadados de cadastro. A senha mestra continua necessária e não tem recuperação.

**Zerar o sistema**, após digitar `APAGAR`, exclui cadastros, cofre, percursos, pontos de restauração e backups automáticos em arquivo. Arquivos exportados pelo usuário permanecem disponíveis.

Não apague a pasta de dados para atualizar o programa. O ZIP não contém cadastros de teste nem banco pronto.

## Biblioteca e planejamento de hunts

Na aba **Hunts**, a nova seção oferece:

- Busca entre 119 criaturas e entidades da base comunitária.
- Vida, experiência base, velocidade e armadura.
- Tipos de ataque, imunidades e danos sem imunidade declarada.
- Fraquezas percentuais somente quando declaradas na configuração.
- Loot de referência com quantidade máxima configurada.
- Dicas de combate por vocação e comportamento da criatura.
- Seleção de um respawn inicial, geração de sequência e acesso aos pontos no mapa.
- Percursos salvos com personagem e notas de supplies.
- Registro de uma hunt com personagem e local preenchidos.

A sequência usa proximidade entre setores no mesmo andar (raio de 80 sqm, até 12 setores), desenhando pontos numerados e linhas tracejadas no mapa ao abrir um ponto. **Não calcula passagem por paredes, portas, escadas ou obstáculos e não garante a melhor rota.** Confira a acessibilidade antes de usar. Os tempos são da configuração base, não monitoramento ao vivo. Para voltar ao planejamento, abra Hunts e seu percurso salvo.

A biblioteca usa arquivos XML do projeto comunitário [Ethaan/mintwall](https://github.com/Ethaan/mintwall/tree/main/server/data/monster), a mesma origem comunitária utilizada pelo mapa. As fontes técnicas ficam documentadas aqui, fora das telas do programa. Foram removidas entradas sem ficha de criatura, duplicação de slime e duas criaturas posteriores/variantes fora do foco adotado.

Os números não são configurações oficiais de Miracle, Mythera ou Exodion. Loot, XP, resistências e respawns podem variar. Não foram importados elementos modernos como gelo, sagrado ou terra como equivalentes automáticos dos elementos antigos. Ausência de imunidade não significa fraqueza nem dano adicional.

## Desenvolvimento

- `index.html`: estrutura das telas e imagens incorporadas.
- `src/styles.css`: aparência.
- `src/app.js`: cadastros, calculadoras, mapa e telas.
- `src/storage.js`: conexão com armazenamento local e migração.
- `src/hunt-guide.js`: biblioteca, planejamento e backups em arquivo.
- `server.cjs`: servidor local, SQLite e backups.

```sh
npm run check
```

O servidor aceita conexões apenas no próprio computador e não publica um site. Esta versão continua executada pelo navegador; o instalador Windows permanece uma etapa posterior.

## Imagens dos itens — 0.31

A lista de loot mostra 286 sprites de itens, extraídos do cliente clássico 7.4 e associados aos IDs de loot pelo arquivo OTB da mesma base. As imagens estão incorporadas ao código e funcionam offline.

## Percursos e supplies — 0.31

Na aba Hunts, gere ou abra um percurso. Use as setas para mudar a ordem, edite pontos e remova os que não quiser. Você pode adicionar coordenadas e marcar o tipo como Respawn, Entrada, Saída ou Perigo, com uma observação opcional. Há limite de 32 pontos por percurso.

Ao abrir um ponto no mapa, a sequência aparece numerada. Entrada é verde, saída é dourada e perigo é vermelho. O botão **Adicionar ponto ao percurso** usa a criatura selecionada ou o centro atual do mapa. Para andares diferentes, as linhas não conectam pontos atravessando a transição entre pisos. Acessos e passagens continuam exigindo conferência manual.

Adicione supplies com quantidade e preço por unidade, marque os itens separados e use **Salvar percurso** para guardar os pontos e a checklist. Alterações no rascunho ainda não salvas são perdidas ao recarregar. **Salvar como novo** cria outro percurso; **Salvar percurso** atualiza o percurso aberto. Cada planejamento guarda o personagem selecionado e sua lista de supplies.

Use **Registrar hunt** no percurso salvo ou escolha o percurso no formulário de hunt. O nome do local é preenchido e os valores de tempo, XP, loot e gastos são informados por você. Custo previsto de supplies e gasto real são separados.

**Rendimento por percurso** compara as sessões vinculadas, por personagem: XP/h = XP total dividido pelas horas totais; lucro/h = lucro total dividido pelas horas totais. O personagem escolhido no planejador filtra a comparação. Sessões antigas sem vínculo continuam disponíveis no comparativo geral. Excluir um percurso mantém suas sessões e o nome registrado na época.

Percursos e supplies estão incluídos nos backups. Backups anteriores, sem os novos campos, continuam compatíveis.

## Organização e cronômetro — 0.31

A aba Hunts agora tem três áreas: **Sessões** (cronômetro, registros e rendimento), **Biblioteca de monstros** (fichas, estratégias e loot) e **Planejador** (percursos, supplies e comparação por percurso). A seleção de criatura e o rascunho de percurso permanecem ao alternar essas áreas.

Em Sessões, escolha personagem, percurso opcional e local, e clique em **Iniciar hunt**. Um percurso salvo também oferece **Cronometrar**; ele inicia para o personagem vinculado ou pede uma seleção se não houver personagem válido. Só uma sessão pode estar ativa.

O cronômetro usa o horário de início e persiste no banco SQLite. Continua contando ao trocar de aba, recarregar ou fechar o navegador enquanto estiver em andamento. Use **Pausar** antes de sair se não quiser contar esse período. **Continuar** retoma sem incluir o tempo pausado.

**Finalizar e registrar** pausa a sessão e abre o formulário com personagem, percurso, local, data de início e duração preenchidos. A duração é arredondada para cima em minutos, com mínimo de 1 minuto; pode ser corrigida no formulário. Preencha XP, loot e gastos reais. A sessão só sai do cronômetro quando a hunt é salva, na mesma gravação do banco. Cancelar o formulário mantém a sessão pausada para continuar ou tentar finalizar novamente.

**Descartar** pede confirmação e apaga apenas o cronômetro, sem registrar uma hunt. Zerar o sistema também remove a sessão ativa. Backups incluem o estado do cronômetro; restaurar uma cópia com cronômetro em andamento retoma a contagem desde o horário nela gravado. Abas desatualizadas precisam ser recarregadas antes de alterar registros.

## Metas por personagem — 0.31

Use **Metas** no cartão de um personagem ou **Definir metas** na Visão geral. Configure separadamente XP, lucro líquido em gp e tempo de hunt em minutos para o dia e a semana. Use zero para desativar uma meta. Os valores devem ser inteiros e não negativos.

A Visão geral mostra o progresso, o valor registrado, o alvo e quanto falta. Selecione Hoje ou Esta semana e, opcionalmente, um personagem. Lucro líquido é loot menos gastos: prejuízo também entra na conta e pode aumentar o que falta para alcançar a meta de lucro. A barra fica entre 0% e 100%, e o sistema sinaliza metas alcançadas.

O dia e a semana seguem o calendário local do computador; a semana começa na segunda-feira. Hunts com data futura não entram no progresso atual. Ao virar o período, o cálculo muda sem apagar as configurações das metas ou as hunts antigas. Reabra a Visão geral para atualizar o período.

**Comparar semanas** mostra a semana atual até hoje versus a anterior completa, com datas, sessões, totais e diferenças. Uma semana atual incompleta não deve ser interpretada como queda de rendimento por si só.

As metas são guardadas junto ao personagem no banco e nos backups. Atualizar level ou skills preserva as metas. Backups anteriores continuam válidos sem metas cadastradas. O código desse recurso fica em `src/goals.js`.

## Revisão geral — 0.31

A validação agora é compartilhada entre o programa e o servidor, abrangendo personagens, hunts, cofre, metas, percursos, supplies e cronômetro. Cadastros inválidos são rejeitados antes da gravação. A migração opcional de dados do navegador não impede a abertura se esse armazenamento estiver bloqueado.

Falhas na pasta de backups deixam um aviso e não impedem a leitura ou a gravação do banco. A indicação **Salvo · verificar backup** informa quando a gravação ocorreu, mas uma cópia automática falhou. Exporte um backup manual e verifique a pasta indicada em Servidores e Backup.

A recuperação por importação pode substituir um cadastro cujo JSON esteja corrompido; o conteúdo anterior é preservado em um arquivo de recuperação quando possível. Foram corrigidos mensagens antigas sobre armazenamento no navegador, o resultado vazio da busca de criaturas e um link técnico restante no mapa.

Os testes de integridade incluídos não exigem dependências extras. Encerre seu servidor antes de rodá-los, pois usam a porta 7474 e criam um banco temporário separado:

```sh
npm run check
npm test
```

Veja `REVISAO.md` para o resumo de escopo e resultados.
