const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),{spawn}=require('node:child_process'),{once}=require('node:events');
const {validateData}=require('../src/validation.js');
const seed=()=>({chars:[{id:'a',name:'Knight teste',server:'Teste',account:'',vocation:'Knight',level:8,base:8,goal:20,skill:10,ml:0}],hunts:[],vault:null});
test('Validação de cadastros e backups não lança exceções e rejeita estados inválidos',()=>{
 assert(validateData(seed()));for(const d of [null,[],{}, {...seed(),chars:[null]}, {...seed(),hunts:[null]}, {...seed(),chars:[{...seed().chars[0],targets:{daily:{xp:-1,profit:0,minutes:0},weekly:{xp:0,profit:0,minutes:0}}}]}])assert.equal(validateData(d),false);
 assert.equal(validateData({...seed(),vault:{salt:'a',iv:'b',cipher:'c'}}),false);
 assert.equal(validateData({...seed(),timer:{id:'t',char:'missing',planId:'',place:'Cave',date:'2026-10-04',elapsedMs:0,startedAt:1,status:'running'}}),false);
});
test('Banco, conflitos, backups, dados corrompidos e reset',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tibia-integrity-'));
 const proc=spawn(process.execPath,[path.join(__dirname,'../server.cjs')],{env:{...process.env,TIBIA_DATA_DIR:dir}});let stderr='';proc.stderr.on('data',d=>stderr+=d);const ready=await Promise.race([once(proc.stdout,'data').then(()=>true),once(proc,'exit').then(()=>false)]);assert(ready,'Servidor não iniciou: '+stderr);
 const url='http://127.0.0.1:7474';let state;
 const read=async()=>{const res=await fetch(url+'/api/state');assert.equal(res.status,200);state=await res.json();return state};
 const write=async(d,rev=state.rev)=>{const res=await fetch(url+'/api/storage',{method:'POST',headers:{'Content-Type':'application/json','X-Tibia-Token':state.token},body:JSON.stringify({key:'tibia-command-v1',value:JSON.stringify(d),rev})});const body=await res.json();if(res.status===200)state.rev=body.rev;return {status:res.status,body}};
 try{
  await read();assert.equal((await write(seed())).status,200);assert(fs.existsSync(path.join(dir,'tibia-command.sqlite')));
  const rev=state.rev;const broken={...seed(),chars:[null]};assert.equal((await write(broken)).status,400);assert.equal((await read()).rev,rev);
  const changed=seed();changed.chars[0].name='Alterado';assert.equal((await write(changed)).status,200);assert.equal((await write(seed(),rev)).status,409);
  assert.equal(JSON.parse((await read()).values['tibia-command-v1']).chars[0].name,'Alterado');assert(state.backups.length>0);
  const previous=await fetch(url+'/api/backup?name='+encodeURIComponent(state.backups[0].name),{headers:{'X-Tibia-Token':state.token}});const backup=await previous.json();assert(validateData(backup.data));assert.equal((await write(backup.data)).status,200);
  for(let i=0;i<34;i++){const d=seed();d.chars[0].name='Teste '+i;assert.equal((await write(d)).status,200)}assert.equal((await read()).backups.length,30);
  // An inaccessible backup directory must not prevent reads or lose a successful save.
  fs.rmSync(path.join(dir,'backups'),{recursive:true});fs.writeFileSync(path.join(dir,'backups'),'blocked');assert.equal((await read()).backups.length,0);const warned=await write(seed());assert.equal(warned.status,200);assert.match(warned.body.warning,/cópia automática/);fs.unlinkSync(path.join(dir,'backups'));fs.mkdirSync(path.join(dir,'backups'));
  const {DatabaseSync}=require('node:sqlite');const db=new DatabaseSync(path.join(dir,'tibia-command.sqlite'));db.prepare('UPDATE kv SET value=? WHERE key=?').run('broken JSON {','tibia-command-v1');db.close();await read();assert.equal((await write(seed())).status,200);assert(fs.readdirSync(path.join(dir,'backups')).some(n=>n.startsWith('recovery-')));
  const unauth=await fetch(url+'/api/storage',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});assert.equal(unauth.status,403);
  const hostile=await fetch(url+'/api/state',{headers:{Origin:'https://example.invalid'}});assert.equal(hostile.status,403);
  const malformed=await fetch(url+'/api/storage',{method:'POST',headers:{'X-Tibia-Token':state.token},body:'broken'});assert.equal(malformed.status,400);
  const reset=await fetch(url+'/api/reset',{method:'POST',headers:{'Content-Type':'application/json','X-Tibia-Token':state.token},body:JSON.stringify({rev:state.rev,confirmation:'APAGAR'})});assert.equal(reset.status,200);const empty=await read();assert.equal(JSON.parse(empty.values['tibia-command-v1']).chars.length,0);assert.equal(fs.readdirSync(path.join(dir,'backups')).length,0);
 }finally{const ended=once(proc,'exit');proc.kill();await ended;fs.rmSync(dir,{recursive:true,force:true})}
});
