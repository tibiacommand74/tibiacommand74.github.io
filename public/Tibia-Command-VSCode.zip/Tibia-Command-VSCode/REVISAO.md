# Revisão geral — Tibia Command 0.31

Concluída em 04/10/2026 (horário de Brasília).

## Correções entregues

- Validação completa compartilhada pelo programa e pelo servidor; rejeição de estados inválidos sem alterar o cadastro.
- Validação dos pontos de restauração, identificação de registros duplicados e rejeição de credenciais em texto aberto nos metadados das contas.
- Abertura preservada quando a leitura opcional do armazenamento do navegador não está disponível.
- Leitura e gravação do banco preservadas quando a pasta de backups está inacessível, com aviso explícito sobre a cópia que falhou.
- Importação de backup válida mesmo com JSON corrompido no cadastro atual; preservação do conteúdo anterior em arquivo de recuperação quando possível.
- Mensagens de conflito entre abas mantidas no erro apresentado ao usuário.
- Busca vazia de criaturas sem mostrar a ficha antiga como se fosse um resultado.
- Textos de armazenamento atualizados para banco local e retirada do link técnico restante no mapa.
- Política de conteúdo e proteção contra incorporação da interface em páginas externas.

## Verificações executadas

| Área | Verificações | Resultado |
| --- | --- | --- |
| Personagens | Criar, duplicidade, editar, busca, perda de level, vínculo com conta e histórico | Passou |
| Calculadoras | XP por level e estágios, combate, shielding, ML/mana, preservação de valores e isolamento dos painéis | Passou |
| Cofre | Criar senha, cadastrar/renomear conta, desbloquear, senha incorreta e bloqueio ao sair | Passou |
| Privacidade do cofre | Ausência das senhas de teste em texto aberto no banco e nos backups | Passou |
| Hunts | Criar/editar sessão, lucro, XP/h, comparação e formulário ligado ao percurso | Passou |
| Percursos e supplies | Gerar, reordenar, editar, salvar sem duplicar, checklist e custo previsto | Passou |
| Cronômetro | Iniciar, pausar, retomar, reabrir, cancelar finalização e registrar apenas uma sessão | Passou |
| Metas | Configuração e preservação ao editar personagem; apresentação no painel | Passou |
| Mapa e loot | Troca de andar, zoom, busca/seleção de respawn, local salvo e imagens dos itens cadastrados | Passou |
| Backup | Exportação/importação, restauração, retenção de 30 arquivos e recuperação de JSON corrompido | Passou |
| Integridade | Rejeição de dados inválidos, conflito entre abas e funcionamento com pasta de backup inacessível | Passou |
| Reset | Confirmação incorreta, exclusão completa e persistência do estado vazio após reabrir | Passou |
| Navegação e layout | Todas as abas no navegador, desktop e largura de 390 px, sem erro JavaScript observado | Passou |

Os testes utilizaram cadastros fictícios e bancos temporários; o pacote não contém esses dados. `npm test` repete os testes de integridade do servidor e da validação. A revisão de interface e dos fluxos foi executada também em navegador automatizado.

## Limites desta revisão

A execução foi verificada em ambiente Linux com Node.js e navegador automatizado. O instalador e a instalação nativa no Windows ainda não foram testados nesta etapa. Os testes das calculadoras verificam a implementação e os exemplos matemáticos; não constituem uma nova consulta dos rates dos servidores. As fontes comunitárias de criaturas, loot e respawns continuam sujeitas a diferenças por servidor. As rotas continuam sendo sequências por proximidade, sem cálculo de passagem por obstáculos.
