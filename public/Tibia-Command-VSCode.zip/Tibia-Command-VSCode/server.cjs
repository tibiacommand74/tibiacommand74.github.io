const {validateData}=require('./src/validation.js');
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
let DatabaseSync;try{({DatabaseSync}=require('node:sqlite'))}catch{console.error('Instale Node.js 22.13 ou superior (recomendado: LTS atual).');process.exit(1)}
const dir=process.env.TIBIA_DATA_DIR||path.join(process.env.LOCALAPPDATA||path.join(os.homedir(),'.local','share'),'TibiaCommand');
fs.mkdirSync(dir,{recursive:true});const backupDir=path.join(dir,'backups');fs.mkdirSync(backupDir,{recursive:true});
const db=new DatabaseSync(path.join(dir,'tibia-command.sqlite'));db.exec('PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY,value TEXT NOT NULL); CREATE TABLE IF NOT EXISTS meta (id INTEGER PRIMARY KEY CHECK(id=1),rev INTEGER NOT NULL); INSERT OR IGNORE INTO meta VALUES(1,0);');
const token=crypto.randomBytes(32).toString('hex'),allowed=new Set(['tibia-command-v1','tibia-command-restore-points','tibia-command-saved-at']);
const revision=()=>db.prepare('SELECT rev FROM meta WHERE id=1').get().rev;
const values=()=>Object.fromEntries(db.prepare('SELECT key,value FROM kv').all().map(r=>[r.key,r.value]));
function backup(){const row=db.prepare('SELECT value FROM kv WHERE key=?').get('tibia-command-v1');if(!row)return;let snapshot;try{snapshot=JSON.parse(row.value)}catch{const raw='recovery-'+Date.now()+'-'+crypto.randomBytes(3).toString('hex')+'.txt';fs.writeFileSync(path.join(backupDir,raw),row.value,{flag:'wx'});return}const file='backup-'+new Date().toISOString().replace(/[:.]/g,'-')+'-'+crypto.randomBytes(3).toString('hex')+'.json';fs.writeFileSync(path.join(backupDir,file),JSON.stringify({format:'tibia-command-v1',data:snapshot},null,2),{flag:'wx'});const list=fs.readdirSync(backupDir).filter(n=>/^backup-.*\.json$/.test(n)).sort();for(const n of list.slice(0,-30))fs.unlinkSync(path.join(backupDir,n));}
function listBackups(){try{return fs.readdirSync(backupDir).filter(n=>/^backup-.*\.json$/.test(n)).sort().reverse().map(name=>({name,at:fs.statSync(path.join(backupDir,name)).mtime.toISOString()}))}catch{return []}}
function send(res,status,obj){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(obj))}
const routes=new Map([['/',['index.html','text/html']],['/index.html',['index.html','text/html']],['/src/styles.css',['src/styles.css','text/css']],['/src/app.js',['src/app.js','text/javascript']],['/src/storage.js',['src/storage.js','text/javascript']],['/src/hunt-guide.js',['src/hunt-guide.js','text/javascript']],['/src/goals.js',['src/goals.js','text/javascript']],['/src/validation.js',['src/validation.js','text/javascript']]]);
const server=http.createServer(async(req,res)=>{try{
 if(req.headers.host!=='127.0.0.1:7474')return send(res,403,{error:'Endereço não permitido.'});
 const origin=req.headers.origin;if(origin&&origin!=='http://127.0.0.1:7474')return send(res,403,{error:'Origem não permitida.'});
 if(req.headers['sec-fetch-site']==='cross-site')return send(res,403,{error:'Origem não permitida.'});
 const url=new URL(req.url,'http://127.0.0.1:7474');
 if(url.pathname.startsWith('/api/')){
  if(req.method==='GET'&&url.pathname==='/api/state')return send(res,200,{values:values(),rev:revision(),token,folder:dir,backups:listBackups()});
  if(req.headers['x-tibia-token']!==token)return send(res,403,{error:'Sessão inválida. Reabra o programa.'});
  if(req.method==='GET'&&url.pathname==='/api/backups')return send(res,200,{backups:listBackups()});
  if(req.method==='GET'&&url.pathname==='/api/backup'){const name=url.searchParams.get('name');if(!listBackups().some(b=>b.name===name))return send(res,404,{error:'Backup não encontrado.'});return send(res,200,JSON.parse(fs.readFileSync(path.join(backupDir,name),'utf8')))}
  if(req.method!=='POST')return send(res,405,{error:'Método inválido.'});
  const chunks=[];let size=0;for await(const part of req){size+=part.length;if(size>12000000)return send(res,413,{error:'Dados acima do limite de 12 MB.'});chunks.push(part)}
  let input;try{input=JSON.parse(Buffer.concat(chunks).toString('utf8'))}catch{return send(res,400,{error:'Solicitação inválida.'})}if(!input||typeof input!=='object'||Array.isArray(input))return send(res,400,{error:'Solicitação inválida.'});if(input.rev!==revision())return send(res,409,{error:'Os dados mudaram em outra aba. Recarregue antes de salvar.'});
  if(url.pathname==='/api/reset'){
   if(input.confirmation!=='APAGAR')return send(res,400,{error:'Confirmação inválida.'});
   // Stage old backups so a failed transaction can restore them.
   const retired=backupDir+'-reset-'+crypto.randomUUID();fs.renameSync(backupDir,retired);try{fs.mkdirSync(backupDir)}catch(e){fs.renameSync(retired,backupDir);throw e}
   try{db.exec('BEGIN IMMEDIATE');db.exec('DELETE FROM kv');db.prepare('INSERT INTO kv VALUES(?,?)').run('tibia-command-v1',JSON.stringify({chars:[],hunts:[],accounts:[],vault:null,mapPins:[],huntPlans:[]}));db.exec('UPDATE meta SET rev=rev+1 WHERE id=1; COMMIT')}catch(e){try{db.exec('ROLLBACK')}catch{}fs.rmdirSync(backupDir);fs.renameSync(retired,backupDir);throw e}
   let warning='';try{fs.rmSync(retired,{recursive:true})}catch{warning='Cadastros zerados, mas algumas cópias antigas não puderam ser apagadas. Verifique a pasta dos dados.'}return send(res,200,{rev:revision(),values:values(),warning});
  }
  if(url.pathname!=='/api/storage'||!allowed.has(input.key)||!(typeof input.value==='string'||input.value===null))return send(res,400,{error:'Dados inválidos.'});
  if(input.key==='tibia-command-restore-points'&&input.value!==null){let points;try{points=JSON.parse(input.value)}catch{return send(res,400,{error:'Cópias inválidas.'})}if(!Array.isArray(points)||points.length>5||!points.every(p=>p&&typeof p.id==='string'&&p.id.length<=200&&typeof p.at==='string'&&Number.isFinite(Date.parse(p.at))&&validateData(p.data)))return send(res,400,{error:'Cópias inválidas.'})}
  if(input.key==='tibia-command-saved-at'&&input.value!==null&&(!Number.isFinite(Date.parse(input.value))||input.value.length>200))return send(res,400,{error:'Data inválida.'});
  let warning='';if(input.key==='tibia-command-v1'){if(input.value===null)return send(res,400,{error:'Use a opção Zerar sistema.'});let d;try{d=JSON.parse(input.value)}catch{return send(res,400,{error:'Cadastro inválido.'})}if(!validateData(d))return send(res,400,{error:'Cadastro inválido. Nenhuma alteração foi gravada.'});try{backup()}catch{warning='Dados salvos, mas a cópia automática em arquivo falhou. Exporte um backup e verifique a pasta dos dados.'}}
  db.exec('BEGIN IMMEDIATE');try{if(input.value===null)db.prepare('DELETE FROM kv WHERE key=?').run(input.key);else db.prepare('INSERT INTO kv VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(input.key,input.value);db.exec('UPDATE meta SET rev=rev+1 WHERE id=1; COMMIT')}catch(e){db.exec('ROLLBACK');throw e}
  return send(res,200,{rev:revision(),warning});
 }
 if(!['GET','HEAD'].includes(req.method))return send(res,405,{error:'Método inválido.'});const route=routes.get(url.pathname);if(!route)return send(res,404,{error:'Arquivo não encontrado.'});const content=fs.readFileSync(path.join(__dirname,route[0]));res.writeHead(200,{'Content-Type':route[1]+'; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"});res.end(req.method==='HEAD'?undefined:content);
}catch(e){console.error(e.message);send(res,500,{error:'Não foi possível acessar os dados locais. Verifique o terminal e o espaço em disco.'})}});
server.on('error',e=>{console.error(e.code==='EADDRINUSE'?'Porta 7474 ocupada. Feche a outra execução e tente novamente.':e.message);process.exitCode=1});
server.listen(7474,'127.0.0.1',()=>{console.log('Tibia Command: http://127.0.0.1:7474');console.log('Dados e backups: '+dir);console.log('Ctrl+C para encerrar.')});
